<?php
/**
 * A vanilla template file
 *
 * This is the most generic template file in a WordPress theme
 * and one of the two required files for a theme (the other being style.css).
 * It is used to display a page when nothing more specific matches a query.
 * e.g., it puts together the home page when no home.php file exists.
 *
 * Learn more: {@link https://codex.wordpress.org/Template_Hierarchy}
 *
 * @package Vanilla
 * @subpackage None
 * @since Never
 */
//printHTML(var_dump(wp_get_themes()), "Themes");


$closeButton = '<li id="wp-admin-bar-search" click="event.currentTarget.parent.style.display=\'none\';" class="admin-bar-search"><div class="ab-item ab-empty-item" tabindex="-1" style="padding:0 12px 0 5">CLOSE</div></li>';

//switch_theme("twentyfifteen");
//return;
//switch_theme("vanilla");
// show our custom template HTML - todo move to a function 
if ( have_posts() ) {
	$PROJECT_HOME_PAGE = "project_home_page";
	$user = wp_get_current_user();
	$blog_id = get_current_blog_id();
	$templateFound = false;
	$isDebug = false;
	//get_current_user_id();
	//var_dump($user);
	
	if (defined('WP_DEBUG') && WP_DEBUG === true) {
		$isDebug = true;
	}
	
	if ($isDebug) {
		printHTML("Blog:$blog_id", "Debug enabled on theme index page");
	}
	
	//echo "User: ".$user;
	if ($user) {
		$user_id = $user->ID;
		
		if ($isDebug) {
			printHTML($user_id, "Current user ID");
		}
		
		//if ($user_id!=0) {
			//$templatePostID = get_user_option(PROJECT_HOME_PAGE, $user_id);
			//$templatePostID = get_blog_option($blog_id, $PROJECT_HOME_PAGE, 0);
		//}
	}
	
	$templatePostID = get_blog_option($blog_id, $PROJECT_HOME_PAGE, 0);
	
	if ($isDebug) {
		printHTML($templatePostID, "ID of user home page template");
	}
	
	$templatePost = null;
	
	if ($templatePostID && $templatePostID!=0 && $templatePostID>0) {
		$templatePost = get_post($templatePostID);
	}
	
	if ($templatePost) {
		//echo "inside template post content"; 
		$userHTML = getUserHTMLContent($templatePost);
		$templateFound = true;
		
		if ($isDebug) {
			printHTML($userHTML, "User template found");
		}
	}
	
	
	//$test = "<!--the loop--><some thing else><!--the loop-->";
	//preg_match('/<!--the loop-->(.*)<!--the loop-->/is', $userHTML, $loopInnerHTML);
	
	//$DETAILS = get_blog_details();
	//var_dump($DETAILS);
	//die();
	
	if ($templateFound) {
		$blogInfo = getBlogInfo();
		$userHTML = replaceBlogTokens($userHTML, $blogInfo);
		
		if ($isDebug) {
			printHTML($userHTML, "User html replaced blog tokens");
		}
		
		$loopTemplateHTML = getLoopHTML($userHTML);
		
		if ($loopTemplateHTML) {
			
			if ($isDebug) {
				printHTML($loopTemplateHTML, "The loop template was found");
			}
			
			$items = array();
			
			while (have_posts()) {
				the_post();
				
				$items[] = replacePostTokens($loopTemplateHTML, $post);
				//echo replacePostTokens($template11, $post);
				
			}
			
			//echo "Number of posts: " . count($items);
			//echo "\n" . implode("\n", $items);
			
			//$theLoopContent = "\n" . implode("\n", $items);
			$theLoopContent = implode("\n", $items);
			
			if ($isDebug) {
				printHTML($theLoopContent, "The loop content after");
			}
			
			$userHTML = replaceLoopToken($userHTML, $theLoopContent);
			
			//printHTML($userHTML, "Final HTML");
		}
		
		echo $userHTML;
		
		// show admin tool bar?
		if (is_user_logged_in()) {
			get_footer();
			echo $closeButton;
		}
		
		die();
	}
	else {
		
		if ($isDebug) {
			get_footer();
			?>
<script>
var bar = document.getElementById('wpadminbar');
var list = document.getElementById('wp-admin-bar-top-secondary');
var item = document.createElement('li');
var anchor = document.createElement('a');
anchor.appendChild(document.createTextNode("CLOSE"));
anchor.className = "ab-item";
item.className = "menupop";
item.style = "cursor:pointer;cursor:hand;";
item.appendChild(anchor);
item.addEventListener("click", function () {
	bar.style.transition = ".5s";
	bar.style.top = "-32";
});
list.insertBefore(item, list.firstChild);
</script>
			<?php 
			echo "Template not found";
		}
	}
	
}
else {
	#echo "******************we have no posts";
}
//echo "<br >****************after the if (have_posts) ";
get_header(); 

?>

	<div id="primary" class="site-content">
		<div id="content" role="main">
		<?php if ( have_posts() ) : ?>

			<?php /* Start the Loop */ ?>
			<?php while ( have_posts() ) : the_post(); ?>
				<?php get_template_part( 'content', get_post_format() ); ?>
			<?php endwhile; ?>

			<?php twentytwelve_content_nav( 'nav-below' ); ?>

		<?php else : ?>

			<article id="post-0" class="post no-results not-found">

			<?php if ( current_user_can( 'edit_posts' ) ) :
				// Show a different message to a logged-in user who can add posts.
			?>
				<header class="entry-header">
					<h1 class="entry-title"><?php _e( 'No posts to display', 'twentytwelve' ); ?></h1>
				</header>

				<div class="entry-content">
					<p><?php printf( __( 'Ready to publish your first post? <a href="%s">Get started here</a>.', 'twentytwelve' ), admin_url( 'post-new.php' ) ); ?></p>
				</div><!-- .entry-content -->

			<?php else :
				// Show the default message to everyone else.
			?>
				<header class="entry-header">
					<h1 class="entry-title"><?php _e( 'Nothing Found', 'twentytwelve' ); ?></h1>
				</header>

				<div class="entry-content">
					<p><?php _e( 'Apologies, but no results were found. Perhaps searching will help find a related post.', 'twentytwelve' ); ?></p>
					<?php get_search_form(); ?>
				</div><!-- .entry-content -->
			<?php endif; // end current_user_can() check ?>

			</article><!-- #post-0 -->

		<?php endif; // end have_posts() check ?>

		</div><!-- #content -->
	</div><!-- #primary -->

<?php get_sidebar(); ?>
<?php get_footer(); ?>
